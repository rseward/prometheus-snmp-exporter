#!/bin/bash

rm -f snmp.yml

podman build -t snmp-generator .

podman run --rm -ti -v "${PWD}:/opt/" snmp-generator generate
ls -l snmp.yml
